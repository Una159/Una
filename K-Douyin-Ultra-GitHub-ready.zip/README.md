# K-Douyin Ultra v0.2 — shared-source development scaffold

Target app: Douyin 40.8.0, bundle ID `com.ss.iphone.ugc.Aweme` (target supplied by user; exact binary interface has not yet been inspected).

## Included and implemented
- Logos/Theos tweak entry point scoped to the target bundle.
- Feature registry with stable IDs, titles, categories, descriptions, and implementation status.
- Persistent feature preferences using `NSUserDefaults`.
- Unified settings UI with live search, category filter, switches, and environment diagnostics.
- Floating `K` launcher to open the settings panel.
- Export preferences as a JSON file through the iOS share sheet.
- Reset settings to defaults.
- Explicit placeholders for feature modules that still need version-specific implementation.

## Not yet implemented / not verified
- Actual video downloading, watermark processing, ad filtering, comment audio replacement, private-message automation, livestream modifications, or other Douyin-internal behavior.
- Successful compilation on a real Theos installation.
- Injection and launch testing on the user's signed IPA or device.
- Compatibility with any app version other than the intended target.

A setting marked **待实现** stores its preference only. It does not imply that the corresponding feature is active.

## Build on a Theos host

```sh
make clean
make
make package
```

Rootless package (on a rootless Theos setup):

```sh
make clean
make package THEOS_PACKAGE_SCHEME=rootless
```

## Raw dylib for an IPA injection workflow

```sh
make clean
make
```

Theos produces the compiled dynamic library under `.theos/obj/` (exact subdirectory varies by SDK/architecture/build mode). Find it with:

```sh
find .theos/obj -name 'KDouyinUltra.dylib' -print
```

The raw dylib is not an IPA. Inject it into a copy of the target IPA with the chosen injection tool and re-sign that IPA. The `.deb` package is for a compatible jailbreak package manager, not for direct import into an IPA injector.

## Version-specific workflow
1. Build this scaffold first.
2. Confirm that the injected dylib is loaded into `com.ss.iphone.ugc.Aweme`.
3. Verify the floating launcher and settings page.
4. Implement each feature behind its registry/config key, then test on the exact app build.
5. Record each module as implemented only after device testing.

The user currently has only an iPhone and uses LCSign; this project has not been compiled on-device. Building a Theos tweak typically requires a suitable build environment or a compatible on-device Theos setup.
